Installation:

Warning: MAKE SURE YOUR READER IS AT LEAST 75% CHARGED before starting installation!!!

1) If you have hundreds of books in internal memory, remove them
2) Unpack PRSPInstaller folder from this archive to the internal memory of the reader, 
   disconnect reader from PC and follow instructions on the screen of the reader. 
   (press "bookmark" button if installer doesn't show up)