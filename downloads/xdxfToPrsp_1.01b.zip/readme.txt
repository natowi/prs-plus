Converter from xdxf visual to prspdict dictionary format.
For usage execute: java -jar xdxfToPrsp.jar
Requirements: Java 1.5+

Note: Use makedict utility (available elsewhere) to convert to xdxf.
Note: "PRS+ Dictionary.exe" is only for testing resulting prspdict files.
