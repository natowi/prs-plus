#!/bin/sh
#
# Idea of igorsk, script by Corwin & igorsk

PATH="/usr/local/bin:/usr/bin:/sbin:/bin:/usr/bin/X11:/usr/games:/usr/local/sony/bin:/usr/sbin"
LD_LIBRARY_PATH="/opt/sony/ebook/application:/lib:/usr/lib:/usr/local/sony/lib:/opt/sony/ebook/lib"
export PATH LD_LIBRARY_PATH

# Intitial variables
# Max Image Size in bytes 7340032 - 100bytes
OPT_IMG_SIZE=7339932

# Temp Working Filesystem
W_FS=/tmp
W_DIR=/tmp/self_upgrade
W_LOG=/tmp/flash.log
RESFILE=/tmp/result.log
M_CARD=`cat /tmp/cardroot`
PRS_VER=`cat /tmp/prsver`

# Binaries
stat_fs=/tmp/bin/stat_fs
date=/bin/date
mkdir=/bin/mkdir
rm=/bin/rm
tar=/bin/tar
mkcramfs=/usr/bin/mkcramfs
mcopy=/tmp/mcopy
#mcopy=/usr/bin/mcopy
chmod=/bin/chmod
du=/usr/bin/du
cut=/usr/bin/cut
nblsdm=/usr/local/sony/bin/nblsdm
umount=/bin/umount
mtdmount=/usr/local/sony/bin/mtdmount

SD_IMG=/tmp/sd_card/new_opt.300.img
SD_MD5=/tmp/sd_card/new_opt.300.md5
TMP_IMG=$W_DIR/new_opt.300.img
TMP_MD5=$W_DIR/new_opt.300.md5

# Max Image Size
if [ "$PRS_VER" = "500" ]; then 
  OPT_IMG_SIZE=7340032
else 
  OPT_IMG_SIZE=8650752
fi
# OPT_IMG_SIZE=51511296
# OPT_IMG_DEV=0
OPT_IMG_DEV=1

echo -n "Begin flashing -> " > $W_LOG
$date >> $W_LOG
echo > $RESFILE

# Copying stat_fs
$mkdir -p /tmp/bin >> $W_LOG 2>&1
$chmod -R ugo+rx /tmp/bin/* >> $W_LOG 2>&1

if [ ! -x $stat_fs ]; then
  echo "No stat_fs found!" >> $W_LOG
  echo -n "1 stat_fs not found." > $RESFILE
  exit 1;
fi

#
# We will copy all necessary files in JS, no need to do it here
#
# mkdir -p $W_DIR
# mkdir -p /tmp/sd_card
mkdir -p /tmp/img_mnt

# echo "Mounting SD card A" >> $W_LOG
# mount -t vfat /dev/sdmscard/sdmsa1 /tmp/sd_card >> $W_LOG 2>&1
# ls -laR /tmp/sd_card >>$W_LOG

UMT=0

if [ -f $TMP_IMG -a -f $TMP_MD5 ]
then
   # cp -f $SD_IMG $TMP_IMG
   REAL_MD5=`/usr/bin/md5sum $TMP_IMG | cut -f1 -d\  `
   TEST_MD5=`cut -f1 -d\  $TMP_MD5 `

   if [ $REAL_MD5 = $TEST_MD5 ]
   then
      echo "Mounting SD card image" >> $W_LOG
      mount -o loop -t cramfs $TMP_IMG /tmp/img_mnt >> $W_LOG 2>&1
      # mount --bind /tmp/img_mnt/bin /bin >> $W_LOG 2>&1
      # mount --bind /tmp/img_mnt/lib /lib >> $W_LOG 2>&1
      # mount --bind /tmp/img_mnt/usr /usr >> $W_LOG 2>&1
      mount --bind /tmp/img_mnt /opt >> $W_LOG 2>&1
      echo "Done mounting SD card image" >> $W_LOG
      UMT=1
   else
      echo "MD5 check failure [$REAL_MD5 != $TEST_MD5]" >> $W_LOG
      echo -n "9 $TMP_IMG MD5 failure." > $RESFILE
      exit 1
   fi
else
   echo "Image or md5 not found" >> $W_LOG
   echo -n "10 Image or MD5 not found on card." > $RESFILE
   exit 1
fi

if [ ! -r $TMP_IMG ]; then
  echo "No $TMP_IMG found!" >> $W_LOG
  echo -n "2 $TMP_IMG not found." > $RESFILE
  exit 1;
fi

echo "Checking cramfs image size ...." >> $W_LOG
NEW_IMG_SIZE=`$du -b $TMP_IMG | $cut -f 1`
echo "Cramfs image size: $NEW_IMG_SIZE" >> $W_LOG

if [ $NEW_IMG_SIZE -gt $OPT_IMG_SIZE ]; then
  echo "Opt image size is too big!" >> $W_LOG
  echo -n "5 The new cramfs image is too big for flashing." > $RESFILE
  exit 1
fi

echo "Image size is OK" >> $W_LOG

/bin/df -k >> $W_LOG

echo "Current partition list" >> $W_LOG
$nblsdm list -l >> $W_LOG 2>&1

# Flashing !!!

echo "Deleting previous Fsk partition..." >> $W_LOG
echo $nblsdm delete Fsk >> $W_LOG

if ! $nblsdm delete Fsk >> $W_LOG 2>&1; then
  echo "Warning: error deleting partition!" >> $W_LOG
fi

echo "Flashing Fsk partition with the new image..." >> $W_LOG
echo $nblsdm create -d $OPT_IMG_DEV -l $OPT_IMG_SIZE -i $TMP_IMG Fsk >> $W_LOG

if ! $nblsdm create -d $OPT_IMG_DEV -l $OPT_IMG_SIZE -i $TMP_IMG Fsk >> $W_LOG 2>&1; then
  echo "Error while flashing partition!" >> $W_LOG
  echo -n "6 Error while flashing partition! It is recommended to switch to recovery mode and use Sony flasher to flash a stock image." > $RESFILE
  exit 1
fi

echo "Checking flashed partition against the image..." >> $W_LOG
echo $nblsdm cmp -i $TMP_IMG Fsk >> $W_LOG

if ! $nblsdm cmp -i $TMP_IMG Fsk >> $W_LOG 2>&1; then
  echo "Partition check failed!" >> $W_LOG
  echo -n "7 Partition check failed! It is recommended to retry flashing immediately or switch to recovery mode and use Sony flasher to flash a stock image." > $RESFILE
  exit 1
fi

#following doesn't work
#echo "Unmounting /opt..." >> $W_LOG
#$umount /opt >> $W_LOG 2>&1
#echo "Remounting /opt..." >> $W_LOG
#$mtdmount -t cramfs Fsk /opt >> $W_LOG 2>&1

echo "Reflashing was successful. Rebooting..." >> $W_LOG

#$mcopy -pnso $W_LOG $M_CARD/
sleep 1

echo -n "0 Reflashing was successful. Rebooting." > $RESFILE

# mkdir -p /tmp/sd_card
# mount -t vfat /dev/sdmscard/sdmsa1 /tmp/sd_card >> $W_LOG 2>&1
if [ -d  /Data/Sony\ Reader/tocopy ]
then
   mkdir -p /Data/database/media/books
   mv -f /Data/Sony\ Reader/tocopy/* /Data/database/media/books
   echo -n " Copy complete." >> $RESFILE
   sync
fi
# umount /tmp/sd_card

# Cleanup...
rm -rf /Data/Sony\ Reader

sync
sync
sync
sync
sync
sync
/sbin/reboot >> $W_LOG 2>&1
exit 0
